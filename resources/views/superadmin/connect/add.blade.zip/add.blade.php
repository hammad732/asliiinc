@extends('admin.layouts.master')

@section('content')
    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
<div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Edit Connect Info  </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <form action="{{route('sa.connect.update')}}" method="post" enctype="multipart/form-data">
        @csrf
            <div class="modal-body">
                <div class="row mb-2">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <label class="mt-1" for="email">Email</label>
                        <input type="text" class="form-control" name="email" id="connect-email-edit" value="{{old('email')}}" required>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <label class="mt-1" for="phone_no">Phone</label>
                        <input type="text" class="form-control" name="phone_no" id="connect-phone-edit" value="{{old('phone_no')}}" required>
                    </div>
                </div>
                <div class="row mb-2">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <label class="mt-1" for="address">address</label>
                        <input type="text" class="form-control" name="address" id="connect-address-edit" value="{{old('address')}}" required>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" name="id" id="connect-id-edit" value="">
                <button type="submit" class="btn btn-success btn-sm">Update</button>
                <button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
            </div>
        </form>
    </div>
</div>
@endsection
